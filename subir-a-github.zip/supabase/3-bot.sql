-- ===== La Clínica del Gym · cuenta del bot de WhatsApp (paso 3) =====
-- Antes: en Authentication → Users → Add user → Create new user, crear
--   email: aron2000tolaba+bot@gmail.com   (o el que pongas abajo)
--   una contraseña larga, y tildar "Auto Confirm User".
-- Después pegar todo esto en SQL Editor → Run.

-- 1) Nuevo rol "bot"
alter table public.perfiles drop constraint if exists perfiles_rol_check;
alter table public.perfiles add constraint perfiles_rol_check check (rol in ('admin', 'tecnico', 'atencion', 'bot'));

create or replace function public.es_bot() returns boolean
language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.perfiles where id = auth.uid() and rol = 'bot') $$;
grant execute on function public.es_bot() to authenticated;

-- 2) El bot puede cargar gastos a nombre de quien le mandó el audio
--    (así cada uno sigue viendo solo los suyos). No puede leer ni editar gastos ajenos.
drop policy if exists "cargar datos" on public.docs;
create policy "cargar datos" on public.docs for insert to authenticated
  with check (public.es_miembro() and (not public.col_privada(col) or public.es_admin() or por = auth.uid() or public.es_bot()));

-- 3) Perfil del bot
insert into public.perfiles (id, usuario, nombre, rol)
select id, 'bot', 'Bot de WhatsApp', 'bot' from auth.users where lower(email) = 'aron2000tolaba+bot@gmail.com'
on conflict (id) do update set usuario = excluded.usuario, nombre = excluded.nombre, rol = excluded.rol;

select case when exists (select 1 from public.perfiles where rol = 'bot') then 'Listo: el bot tiene su cuenta'
            else 'FALTA crear el usuario del bot en Authentication → Users' end as resultado;
