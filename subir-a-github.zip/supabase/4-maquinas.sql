-- ===== La Clínica del Gym · máquinas con QR (paso 4) =====
-- Pegar todo en Supabase → SQL Editor → Run. Se puede correr más de una vez.
-- Las máquinas, sedes y trabajos se guardan en la tabla "docs" como el resto de la app;
-- esto solo agrega la ficha pública del QR y el lugar para las fotos.

-- 1) Ficha pública: lo que ve cualquiera que escanea el QR, sin entrar.
--    Solo estado, último service y próxima visita. Nada de precios ni datos del cliente.
create index if not exists docs_token_maquina on public.docs ((data->>'token')) where col = 'equipos';

create or replace function public.ficha_maquina(p_token text) returns json
language sql stable security definer set search_path = public
as $$
  select json_build_object(
    'codigo',     e.data->>'codigo',
    'equipo',     e.data->>'tipo' || case when (select count(*) from public.docs x where x.col = 'equipos' and not x.borrado
                    and x.data->>'sedeId' = e.data->>'sedeId' and x.data->>'modelo' = e.data->>'modelo') > 1
                    then ' ' || coalesce(e.data->>'numInterno', '') else '' end,
    'modelo',     e.data->>'modelo',
    'ubicacion',  e.data->>'ubicacion',
    'estado',     coalesce(e.data->>'estado', 'Operativa'),
    'sede',       (select s.data->>'nombre' from public.docs s where s.col = 'sedes' and s.id = e.data->>'sedeId' and not s.borrado),
    'ultimo',     t.data->>'fecha',
    'ultimoTipo', t.data->>'tipo',
    'proxima',    t.data->>'proxima',
    'telefono',   (select c.data->'v'->>'telefono' from public.docs c where c.col = 'meta' and c.id = 'config'),
    'negocio',    (select c.data->'v'->>'negocio' from public.docs c where c.col = 'meta' and c.id = 'config'))
  from public.docs e
  left join lateral (select d.data from public.docs d where d.col = 'trabajos' and not d.borrado and d.data->>'equipoId' = e.id
                     order by d.data->>'fecha' desc limit 1) t on true
  where length(p_token) between 10 and 32 and e.col = 'equipos' and not e.borrado
    and e.data->>'sedeId' is not null and e.data->>'token' = p_token
  limit 1
$$;
revoke all on function public.ficha_maquina(text) from public;
grant execute on function public.ficha_maquina(text) to anon, authenticated;

-- 2) Fotos: carpeta privada "fotos" en Storage (no pesan en los celulares).
--    Solo ustedes pueden verlas y subirlas; borrar, solo el administrador.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fotos', 'fotos', false, 3145728, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do nothing;

drop policy if exists "fotos: ver" on storage.objects;
create policy "fotos: ver" on storage.objects for select to authenticated
  using (bucket_id = 'fotos' and public.es_miembro());
drop policy if exists "fotos: subir" on storage.objects;
create policy "fotos: subir" on storage.objects for insert to authenticated
  with check (bucket_id = 'fotos' and public.es_miembro());
drop policy if exists "fotos: borrar" on storage.objects;
create policy "fotos: borrar" on storage.objects for delete to authenticated
  using (bucket_id = 'fotos' and public.es_admin());

select 'Listo: ficha pública y fotos' as resultado;
